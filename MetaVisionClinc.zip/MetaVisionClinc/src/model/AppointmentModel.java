/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.sql.*;
import java.util.Vector;
import javax.swing.DefaultComboBoxModel;
import javax.swing.table.DefaultTableModel;

public class AppointmentModel {
        private final String dbUrl = "jdbc:mysql://localhost:3306/clinc_db";
    private final String dbUser = "root";
    private final String dbPass = "";

    public void saveAppointment(int patientId, int doctorId, String date, String serviceType, String notes) throws SQLException {
        try (Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPass)) {
            PreparedStatement stmt = conn.prepareStatement(
                "INSERT INTO appointments (Pat_id, Did, date, service_type, notes) VALUES (?, ?, ?, ?, ?)"
            );
            stmt.setInt(1, patientId);
            stmt.setInt(2, doctorId);
            stmt.setString(3, date);
            stmt.setString(4, serviceType);
            stmt.setString(5, notes);
            stmt.executeUpdate();
        }
    }

    public DefaultTableModel loadAppointmentsTable() throws SQLException {
        try (Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);
             PreparedStatement stmt = conn.prepareStatement(
                 "SELECT a.Aid, p.FullName, d.Doc_name, a.date, a.service_type, a.notes " +
                 "FROM appointments a " +
                 "JOIN patients p ON a.Pat_id = p.Pid " +
                 "JOIN doctor d ON a.Did = d.Did");
             ResultSet rs = stmt.executeQuery()) {

            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();

            Vector<String> columnNames = new Vector<>();
            for (int i = 1; i <= columnCount; i++) {
                columnNames.add(metaData.getColumnName(i));
            }

            Vector<Vector<Object>> data = new Vector<>();
            while (rs.next()) {
                Vector<Object> row = new Vector<>();
                for (int i = 1; i <= columnCount; i++) {
                    row.add(rs.getObject(i));
                }
                data.add(row);
            }

            return new DefaultTableModel(data, columnNames);
        }
    }

    public DefaultComboBoxModel<String> loadPatients() throws SQLException {
        DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();
        try (Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);
             PreparedStatement stmt = conn.prepareStatement("SELECT Pid, FullName FROM patients");
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                model.addElement(rs.getInt("Pid") + " - " + rs.getString("FullName"));
            }
        }
        return model;
    }

    public DefaultComboBoxModel<String> loadDoctors() throws SQLException {
        DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();
        try (Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);
             PreparedStatement stmt = conn.prepareStatement("SELECT Did, Doc_name FROM doctor");
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                model.addElement(rs.getInt("Did") + " - " + rs.getString("Doc_name"));
            }
        }
        return model;
    }

}
