/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author my dell
 */
public class Doctor {
    private int id;
    private String name;
    private String availability;
    private String contact;

    public Doctor(int id, String name, String availability, String contact) {
        this.id = id;
        this.name = name;
        this.availability = availability;
        this.contact = contact;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getAvailability() { return availability; }
    public String getContact() { return contact; }

}
