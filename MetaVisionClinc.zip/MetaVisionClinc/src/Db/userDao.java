/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Db;

import model.user;
import java.sql.*;

/**
 *
 * @author my dell
 */
public class userDao {
    private final String dbUrl = "jdbc:mysql://localhost:3306/clinc_db";
    private final String dbUser = "root";
    private final String dbPass = "";

    public boolean validateUser(user user) {
        try (Connection con = DriverManager.getConnection(dbUrl, dbUser, dbPass)) {
            String query = "SELECT * FROM login WHERE username = ? AND password = ?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getPassword());

            ResultSet rs = ps.executeQuery();
            return rs.next(); // true if match found
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

}
