/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Db;

import java.sql.*;
import java.sql.Connection;
import javax.swing.JOptionPane;
/**
 *
 * @author my dell
 */
public class tables {
    
    public static void main(String[] args){
        Connection con = null;
        Statement st = null;
        try{
            con = Connectionprovider.getCon();
            st = con.createStatement();
            st.executeUpdate("create table");
        }
        catch(Exception e){
            JOptionPane.showConfirmDialog(null, e);
            }
            finally{
            try{
                con.close();
                st.close();
            }
            catch(Exception e){
                
            }
        }
                
      }
    }

