/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Db;

import model.Patient;
import java.sql.*;

public class PatientDAO {
    private final String dbUrl = "jdbc:mysql://localhost:3306/clinc_db";
    private final String dbUser = "root";
    private final String dbPass = "";

    public boolean addPatient(Patient patient) {
        try (Connection con = DriverManager.getConnection(dbUrl, dbUser, dbPass)) {
            String sql = "INSERT INTO patients (FullName, age, gender, contact, address) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, patient.getName());
            ps.setInt(2, patient.getAge());
            ps.setString(3, patient.getGender());
            ps.setString(4, patient.getContact());
            ps.setString(5, patient.getAddress());

            int result = ps.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

}
