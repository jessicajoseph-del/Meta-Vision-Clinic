/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Db;

import model.Doctor;
import java.sql.*;
/**
 *
 * @author my dell
 */
public class DoctorDAO {
    private final String dbUrl = "jdbc:mysql://localhost:3306/clinc_db";
    private final String dbUser = "root";
    private final String dbPass = "";
    
    public boolean addDoctor(Doctor doctor) {
    try (Connection con = DriverManager.getConnection(dbUrl, dbUser, dbPass)) {
        PreparedStatement stmt = con.prepareStatement(
            "INSERT INTO doctor (Doc_name, Available, Contact) VALUES (?, ?, ?)"
        );
        stmt.setString(1, doctor.getName());
        stmt.setString(2, doctor.getAvailability());
        stmt.setString(3, doctor.getContact());

        int rowsInserted = stmt.executeUpdate();
        return rowsInserted > 0;
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}

}
