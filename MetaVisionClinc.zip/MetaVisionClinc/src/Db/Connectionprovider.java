/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Db;

import java.sql.Connection;
import java.sql.DriverManager;
/**
 *
 * @author my dell
 */
public class Connectionprovider {
    
    public static Connection getCon(){
        try{
            Class.forName("con.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinc_db", "root", "");
            return con;
        }
        catch(Exception e){
            System.out.println(e);
            return null;
        }
    }
}
