/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import Db.userDao;
import model.user;

/**
 *
 * @author my dell
 */
public class LoginController {
     private userDao db = new userDao();

    public boolean authenticate(String username, String password) {
        user user = new user(username, password);
        return db.validateUser(user);
    }

}
