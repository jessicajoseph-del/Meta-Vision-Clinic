/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import Db.DoctorDAO;
import model.Doctor;
/**
 *
 * @author my dell
 */
public class AddDoctorController {
    private DoctorDAO dao = new DoctorDAO();

    public boolean addNewDoctor(String name, boolean isAvailable, String contact) {
        String availability = isAvailable ? "Yes" : "No";
        Doctor doctor = new Doctor(0, name, availability, contact);
        return dao.addDoctor(doctor);
    }

}
