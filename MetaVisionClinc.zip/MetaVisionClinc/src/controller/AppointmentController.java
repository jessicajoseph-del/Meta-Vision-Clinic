/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import model.AppointmentModel;
import view.AppointmentsView;

import javax.swing.JOptionPane;

public class AppointmentController {
     private final AppointmentsView view;
    private final AppointmentModel model;

    public AppointmentController(AppointmentsView view, AppointmentModel model) {
        this.view = view;
        this.model = model;

        init();
    }

    private void init() {
        try {
            view.Pid.setModel(model.loadPatients());
            view.Did.setModel(model.loadDoctors());
            view.LoadDataTable.setModel(model.loadAppointmentsTable());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(view, "Error initializing data: " + e.getMessage());
        }

        view.SubmitBtn.addActionListener(e -> handleSubmit());
        view.Back.addActionListener(e -> handleBack());
    }

    private void handleSubmit() {
        try {
            String patientEntry = view.Pid.getSelectedItem().toString();
            String doctorEntry = view.Did.getSelectedItem().toString();
            int patientId = Integer.parseInt(patientEntry.split(" - ")[0]);
            int doctorId = Integer.parseInt(doctorEntry.split(" - ")[0]);

            String date = view.date.getText().trim();
            String serviceType = view.service_type.getSelectedItem().toString().trim();
            String notes = view.notes.getText();

            if (date.isEmpty() || serviceType.isEmpty()) {
                JOptionPane.showMessageDialog(view, "Please fill in the appointment date and reason.");
                return;
            }

            model.saveAppointment(patientId, doctorId, date, serviceType, notes);
            JOptionPane.showMessageDialog(view, "Appointment added successfully!");
            view.LoadDataTable.setModel(model.loadAppointmentsTable());

        } catch (Exception e) {
            JOptionPane.showMessageDialog(view, "Error saving appointment: " + e.getMessage());
        }
    }

    private void handleBack() {
        view.dispose();
        new view.DashboardView().setVisible(true);
    }


}
